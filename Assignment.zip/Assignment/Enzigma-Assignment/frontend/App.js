import React, { useState } from 'react';

function App() {
  const [form, setForm] = useState({
    assignedTo: '',
    status: '',
    dueDate: '',
    priority: '',
    description: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleCancel = () => {
    setForm({
      assignedTo: '',
      status: '',
      dueDate: '',
      priority: '',
      description: ''
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', form);
    // Add API logic here if needed
  };

  return (
    <div style={{ width: '600px', margin: '40px auto', padding: '20px', border: '1px solid #ccc' }}>
      <h2 style={{ textAlign: 'center' }}>New Task</h2>

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', gap: '20px', marginBottom: '15px' }}>
          <div style={{ flex: 1 }}>
            <label>Assigned To *</label><br />
            <select name="assignedTo" value={form.assignedTo} onChange={handleChange} required style={{ width: '100%' }}>
              <option value="">Select User</option>
              <option value="User 1">User 1</option>
              <option value="User 2">User 2</option>
            </select>
          </div>

          <div style={{ flex: 1 }}>
            <label>Status *</label><br />
            <select name="status" value={form.status} onChange={handleChange} required style={{ width: '100%' }}>
              <option value="">Select Status</option>
              <option value="Not Started">Not Started</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '20px', marginBottom: '15px' }}>
          <div style={{ flex: 1 }}>
            <label>Due Date</label><br />
            <input type="date" name="dueDate" value={form.dueDate} onChange={handleChange} style={{ width: '100%' }} />
          </div>

          <div style={{ flex: 1 }}>
            <label>Priority *</label><br />
            <select name="priority" value={form.priority} onChange={handleChange} required style={{ width: '100%' }}>
              <option value="">Select Priority</option>
              <option value="Low">Low</option>
              <option value="Normal">Normal</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <label>Description</label><br />
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            rows="4"
            style={{ width: '100%' }}
          />
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
          <button type="button" onClick={handleCancel}>Cancel</button>
          <button type="submit">Save</button>
        </div>
      </form>
    </div>
  );
}

export default App;
