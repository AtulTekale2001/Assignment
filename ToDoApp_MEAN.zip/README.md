# ToDoApp MEAN Stack

## Backend
- Node.js
- Express.js
- MongoDB
- APIs: GET /api/tasks, POST /api/task, PUT /api/task/:id, DELETE /api/task/:id

## Frontend
- Angular
- Task List Component
- Task Form Component

## Setup Instructions
1. Navigate to `backend/` and run:
   ```
   npm install
   node server.js
   ```

2. Navigate to `frontend/` and run:
   ```
   npm install
   ng serve
   ```

Ensure MongoDB is running locally or set your connection string in `backend/config/db.js`.
